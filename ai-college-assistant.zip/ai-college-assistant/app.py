import os

from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
from google import genai


# =========================
# LOAD ENVIRONMENT
# =========================

load_dotenv()


# =========================
# CREATE FLASK APP
# =========================

app = Flask(__name__)


# =========================
# GEMINI CLIENT
# =========================

api_key = os.getenv("GEMINI_API_KEY")

client = genai.Client(api_key=api_key)


# =========================
# LOAD COLLEGE INFORMATION
# =========================

with open("college_data.txt", "r", encoding="utf-8") as file:

    college_info = file.read()


# =========================
# CONVERSATION MEMORY
# =========================

conversation_history = []


# =========================
# CLEAR CHAT MEMORY
# =========================

@app.route("/clear-chat", methods=["POST"])
def clear_chat():

    conversation_history.clear()

    return jsonify({
        "success": True
    })


# =========================
# HOME PAGE
# =========================

@app.route("/")
def home():

    return render_template("index.html")


# =========================
# CHAT
# =========================

@app.route("/chat", methods=["POST"])
def chat():

    data = request.get_json()

    user_message = data.get("message", "").strip()


    if not user_message:

        return jsonify({
            "reply": "Please type a question."
        })


    try:

        # Add user message to memory

        conversation_history.append(
            f"Student: {user_message}"
        )


        # Keep recent conversation

        recent_history = conversation_history[-10:]

        conversation_text = "\n".join(
            recent_history
        )


        # =========================
        # AI PROMPT
        # =========================

        prompt = f"""
You are an AI College Assistant.

Your job is to help college students with clear,
friendly and useful answers.

Use the college information provided below.

================================
COLLEGE INFORMATION
================================

{college_info}


================================
CONVERSATION HISTORY
================================

{conversation_text}


================================
ANSWER RULES
================================

1. Answer the student's question directly.

2. Use the college information whenever possible.

3. Do NOT invent college information.

4. If the information is not available, clearly say:
   "I don't have that information in my college database."

5. Keep answers simple and easy for students to understand.

6. Prefer short answers instead of very long paragraphs.

7. When explaining information, use bullet points.

8. Use a clear heading when appropriate.

9. For processes, use numbered steps.

10. Highlight important words using **bold text**.

11. Use emojis only when they make the answer easier
    to understand. Do not overuse emojis.

12. Understand follow-up questions using the
    conversation history.

13. Be polite and professional.

14. Never claim something is true if it is not
    present in the college information.


================================
LATEST STUDENT QUESTION
================================

{user_message}
"""


        # =========================
        # GEMINI REQUEST
        # =========================

        interaction = client.interactions.create(
            model="gemini-3.5-flash-lite",
            input=prompt
        )


        answer = interaction.output_text


        # =========================
        # SAVE AI RESPONSE
        # =========================

        conversation_history.append(
            f"Assistant: {answer}"
        )


        # =========================
        # SEND RESPONSE
        # =========================

        return jsonify({
            "reply": answer
        })


    except Exception as e:

        print("GEMINI ERROR:", repr(e))


        return jsonify({
            "reply": "Sorry, I couldn't process your question right now."
        }), 500


# =========================
# RUN APPLICATION
# =========================

if __name__ == "__main__":

    app.run(debug=True)