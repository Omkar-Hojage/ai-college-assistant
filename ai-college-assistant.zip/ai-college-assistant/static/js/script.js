const messageInput = document.getElementById("messageInput");
const chatBox = document.getElementById("chatBox");
const sendButton = document.getElementById("sendButton");
const clearChatButton = document.getElementById("clearChatButton");


// =========================
// BUTTON EVENTS
// =========================

sendButton.addEventListener("click", sendMessage);

clearChatButton.addEventListener("click", clearChat);


// Press Enter to send
messageInput.addEventListener("keypress", function(event) {

    if (event.key === "Enter") {
        sendMessage();
    }

});


// =========================
// CURRENT TIME
// =========================

function getCurrentTime() {

    const now = new Date();

    return now.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit"
    });

}


// =========================
// FORMAT AI RESPONSE
// =========================

function formatAIResponse(text) {

    let formatted = escapeHTML(text);

    // Bold text: **text**
    formatted = formatted.replace(
        /\*\*(.*?)\*\*/g,
        "<strong>$1</strong>"
    );

    // Bullet points
    formatted = formatted.replace(
        /^\s*[-*]\s+(.*)$/gm,
        "<li>$1</li>"
    );

    // Numbered lists
    formatted = formatted.replace(
        /^\s*(\d+)\.\s+(.*)$/gm,
        "<li>$2</li>"
    );

    // Group consecutive list items
    formatted = formatted.replace(
        /(<li>.*<\/li>\s*)+/gs,
        function(match) {
            return "<ul>" + match + "</ul>";
        }
    );

    // Line breaks
    formatted = formatted.replace(/\n/g, "<br>");

    return formatted;
}


// =========================
// USER MESSAGE
// =========================

function addUserMessage(message) {

    const messageDiv = document.createElement("div");

    messageDiv.className = "message user-message";

    messageDiv.innerHTML = `
        <div class="avatar">👤</div>

        <div class="message-content">

            <p>${escapeHTML(message)}</p>

            <span class="time">
                ${getCurrentTime()}
            </span>

        </div>
    `;

    chatBox.appendChild(messageDiv);

    scrollToBottom();
}


// =========================
// BOT MESSAGE
// =========================

function addBotMessage(message) {

    const messageDiv = document.createElement("div");

    messageDiv.className = "message bot-message";

    messageDiv.innerHTML = `
        <div class="avatar">🤖</div>

        <div class="message-content">

            <div class="bot-text">
                ${formatAIResponse(message)}
            </div>

            <span class="time">
                ${getCurrentTime()}
            </span>

        </div>
    `;

    chatBox.appendChild(messageDiv);

    scrollToBottom();
}


// =========================
// TYPING INDICATOR
// =========================

function showTypingIndicator() {

    const typingMessage = document.createElement("div");

    typingMessage.className = "message bot-message";

    typingMessage.id = "typingMessage";

    typingMessage.innerHTML = `
        <div class="avatar">🤖</div>

        <div class="message-content">

            <p>AI is typing... ⏳</p>

        </div>
    `;

    chatBox.appendChild(typingMessage);

    scrollToBottom();
}


function removeTypingIndicator() {

    const typingMessage =
        document.getElementById("typingMessage");

    if (typingMessage) {
        typingMessage.remove();
    }

}


// =========================
// SEND MESSAGE
// =========================

function sendMessage() {

    const message = messageInput.value.trim();

    if (message === "") {
        return;
    }


    // Show user's message
    addUserMessage(message);


    // Clear input
    messageInput.value = "";


    // Show typing indicator
    showTypingIndicator();


    // Disable send button
    sendButton.disabled = true;

    sendButton.textContent = "Thinking...";


    // Send message to Flask
    fetch("/chat", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({
            message: message
        })

    })

    .then(response => response.json())

    .then(data => {

        // Remove typing indicator
        removeTypingIndicator();


        // Show formatted AI response
        addBotMessage(data.reply);


        // Enable send button
        sendButton.disabled = false;

        sendButton.textContent = "Send ➤";

    })

    .catch(error => {

        console.error("Chat error:", error);


        // Remove typing indicator
        removeTypingIndicator();


        // Show error
        addBotMessage(
            "Sorry, I couldn't connect to the AI right now."
        );


        // Enable send button
        sendButton.disabled = false;

        sendButton.textContent = "Send ➤";

    });

}


// =========================
// QUICK QUESTIONS
// =========================

function sendQuickMessage(message) {

    messageInput.value = message;

    sendMessage();

}


// =========================
// CLEAR CHAT
// =========================

function clearChat() {

    const confirmed = confirm(
        "Are you sure you want to clear the conversation?"
    );

    if (!confirmed) {
        return;
    }


    // Tell Flask to clear AI memory
    fetch("/clear-chat", {

        method: "POST"

    })

    .then(response => response.json())

    .then(data => {

        if (data.success) {

            // Clear chat
            chatBox.innerHTML = "";


            // Add welcome message
            const welcomeMessage =
                document.createElement("div");

            welcomeMessage.className =
                "message bot-message";

            welcomeMessage.innerHTML = `
                <div class="avatar">🤖</div>

                <div class="message-content">

                    <p>
                        Hello! 👋 I'm your AI College Assistant.
                    </p>

                    <p>
                        How can I help you today?
                    </p>

                    <span class="time">
                        Now
                    </span>

                </div>
            `;

            chatBox.appendChild(welcomeMessage);


            // Clear input
            messageInput.value = "";


            scrollToBottom();

        }

    })

    .catch(error => {

        console.error(
            "Clear chat error:",
            error
        );

    });

}


// =========================
// SCROLL CHAT
// =========================

function scrollToBottom() {

    chatBox.scrollTop =
        chatBox.scrollHeight;

}


// =========================
// SECURITY
// =========================

function escapeHTML(text) {

    const div =
        document.createElement("div");

    div.textContent = text;

    return div.innerHTML;

}